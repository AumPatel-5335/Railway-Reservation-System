# CRC Cards — Railway Reservation System

One card (table) per surviving class from the noun-verb analysis.

---

### Class: Passenger

| Responsibilities | Collaborators |
|---|---|
| Provide personal & contact details (name, age, gender, contact) | Ticket |
| Search for trains and view available options | Train |
| Select a train and, optionally, a preferred seat | Seat |
| Initiate booking and make payment | Payment |
| View existing bookings by PNR | Ticket |
| Request cancellation of a ticket | Ticket |
| Receive booking/cancellation notifications | Notification |

---

### Class: Train

| Responsibilities | Collaborators |
|---|---|
| Store train number, name, source, destination, timings, base fare | Railway Administrator |
| Report matching results for a search (source/destination/date/class) | Passenger |
| Own its collection of seats and report seat availability | Seat |
| Update its own status (on-time/delayed) on scheduler trigger | Ticket |

---

### Class: Seat

| Responsibilities | Collaborators |
|---|---|
| Track seat number, travel class, and current status (Available/Reserved) | Train |
| Reserve itself when a ticket is booked | Ticket |
| Release itself when a ticket is cancelled | Ticket |

---

### Class: Ticket

| Responsibilities | Collaborators |
|---|---|
| Generate and hold a unique PNR number | Payment |
| Record journey date, travel class, and status (Confirmed/Cancelled) | Passenger |
| Link a Passenger to a Train, a Seat and a Payment | Train, Seat |
| Check cancellation eligibility and coordinate cancellation | Refund |
| Trigger a notification on booking/cancellation | Notification |

---

### Class: Payment

| Responsibilities | Collaborators |
|---|---|
| Record amount, payment method, status, and payment date | Ticket |
| Submit the transaction to the Payment Gateway for processing | Payment Gateway |
| Confirm successful payment back to the Ticket | Ticket |
| Initiate a Refund when a paid ticket is cancelled | Refund |

---

### Class: Refund

| Responsibilities | Collaborators |
|---|---|
| Calculate the applicable refund amount for a cancelled ticket | Payment |
| Track refund status (Initiated/Processed) and refund date | Ticket |
| Submit the refund request to the Payment Gateway | Payment Gateway |

---

### Class: Railway Administrator

| Responsibilities | Collaborators |
|---|---|
| Add, modify, or remove trains | Train |
| Manage routes, schedules, and fares | Train |
| Manage overall seat availability/capacity per train | Seat |

---

### Class: Payment Gateway

| Responsibilities | Collaborators |
|---|---|
| Authorize and process an online payment transaction | Payment |
| Report success/failure of a transaction | Payment |
| Process refund transactions | Refund |

---

### Class: Notification

| Responsibilities | Collaborators |
|---|---|
| Compose a booking or cancellation message | Ticket |
| Record notification type and timestamp | Passenger |
| Send the message to the relevant Passenger | Passenger |
