# Noun–Verb Analysis — Railway Reservation System

Source material: the three fully specified use cases — **Book Ticket**,
**Cancel Ticket**, and **Search Train** (main flows + alternate flows),
plus the Actors table and Problem Statement.

## 1. Raw Candidate List

Every noun / noun phrase pulled from the three specifications, in the
order it first appears (duplicates merged):

Passenger, System, Train, Seat availability, Passenger details, Fare,
Payment, Payment Gateway, Reservation, PNR number, Ticket, Booking
confirmation, Source station, Destination station, Journey date, Travel
class, Booking details, Ticket information, Cancellation, Cancellation
eligibility, Refund, Booking database, Cancellation rules, Cancellation
confirmation, Search information, Train database, Matching trains,
Train number, Train name, Departure time, Arrival time, Availability,
Suitable train, Search criteria, Route/date, Search details, Error
message, Railway Administrator, Notification Service, Notification,
Scheduler/Timer, Route, Schedule, Transaction, Passenger information,
Contact information, Name, Age, Gender, Seat.

**32 distinct candidates after merging obvious spelling/phrase
duplicates** (e.g. "Booking confirmation" and "Cancellation
confirmation" are kept separate below because they are tested
separately against the filters).

## 2. The Four Filters

Standard noun-verb-analysis (Abbott-style) filters used to prune the
raw list down to real candidate classes:

| # | Filter | Meaning |
|---|--------|---------|
| F1 | **Redundant** | A synonym or near-duplicate of a candidate already kept |
| F2 | **Vague** | Too fuzzy / not a distinct, well-bounded concept in this domain |
| F3 | **Attribute** | Really a property (data value) of another candidate, not a class of its own |
| F4 | **Operation** | Really a verb/behaviour in disguise, not a thing |

`System` is dropped outright — it is the system boundary itself, never
a domain class.

## 3. Filter Applied to Every Discarded Candidate

| Candidate | Filter | Reasoning |
|---|---|---|
| System | — | System boundary, not a domain object |
| Reservation | F1 Redundant | Same concept as **Ticket** (a confirmed reservation *is* the ticket) |
| Booking details | F1 Redundant | Same concept as **Ticket** |
| Ticket information | F1 Redundant | Same concept as **Ticket** |
| Booking confirmation | F1 Redundant | Same concept as **Notification** |
| Cancellation confirmation | F1 Redundant | Same concept as **Notification** |
| Passenger information | F1 Redundant | Same concept as **Passenger details** |
| Contact information | F1 Redundant | Same concept as **Passenger details** |
| Transaction | F1 Redundant | Same concept as **Payment** |
| Search information | F2 Vague | No independent identity — it is just the values a Passenger types in |
| Search details | F2 Vague | Same as above |
| Search criteria | F2 Vague | Same as above |
| Error message | F2 Vague | A transient UI message, not a persistent domain concept |
| Matching trains | F2 Vague | A result *set* of Train, not a new class |
| Suitable train | F2 Vague | Just a Train the passenger picked |
| Availability | F3 Attribute | Becomes the `status`/`seatCount` attribute of **Seat** / **Train** |
| Seat availability | F3 Attribute | Same as above |
| Passenger details | F3 Attribute | Becomes name/age/gender/contact attributes of **Passenger** |
| Name | F3 Attribute | Attribute of Passenger |
| Age | F3 Attribute | Attribute of Passenger |
| Gender | F3 Attribute | Attribute of Passenger |
| Fare | F3 Attribute | Attribute of **Train** (base fare) and **Ticket**/**Payment** (charged amount) |
| PNR number | F3 Attribute | Attribute (identifier) of **Ticket** |
| Source station | F3 Attribute | Attribute of **Train** |
| Destination station | F3 Attribute | Attribute of **Train** |
| Journey date | F3 Attribute | Attribute of **Ticket** |
| Travel class | F3 Attribute | Attribute of **Ticket** / **Seat** |
| Train number | F3 Attribute | Attribute of **Train** |
| Train name | F3 Attribute | Attribute of **Train** |
| Departure time | F3 Attribute | Attribute of **Train** |
| Arrival time | F3 Attribute | Attribute of **Train** |
| Cancellation eligibility | F3 Attribute | Becomes a derived attribute/rule on **Ticket** |
| Cancellation rules | F3 Attribute | Same as above — business rule, not a class |
| Booking database | F3 Attribute | Implementation construct (a persistence detail), not a domain class |
| Train database | F3 Attribute | Same — implementation construct |
| Route | F3 Attribute | Attribute of **Train** (this project keeps routing simple; no separate Route class) |
| Schedule | F3 Attribute | Attribute of **Train** (departure/arrival time already capture it) |
| Route/date | F3 Attribute | Search parameter, folds into Train/Ticket attributes |
| Cancellation | F4 Operation | The verb "cancel" acting on a Ticket — not a noun-class |
| Scheduler/Timer | F4 Operation | A time-triggered actor that *invokes* `updateTrainStatus()`; modelled as an actor, not a domain class |

## 4. Surviving Candidate Classes

After all four filters, **9 classes** survive as genuine, well-bounded
domain concepts:

1. **Passenger**
2. **Train**
3. **Seat**
4. **Ticket**
5. **Payment**
6. **Refund**
7. **Railway Administrator**
8. **Payment Gateway**
9. **Notification**

These carry through into the CRC cards and the class diagram below.
